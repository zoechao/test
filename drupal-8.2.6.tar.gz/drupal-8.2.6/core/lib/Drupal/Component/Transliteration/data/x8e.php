<?php

/**
 * @file
 * Generic transliteration data for the PhpTransliteration class.
 */

$base = array(
  0x00 => 'chu', 'jing', 'nie', 'xiao', 'bu', 'xue', 'cun', 'mu', 'shu', 'liang', 'yong', 'jiao', 'chou', 'qiao', 'mou', 'ta',
  0x10 => 'jian', 'qi', 'wo', 'wei', 'chuo', 'jie', 'ji', 'nie', 'ju', 'ju', 'lun', 'lu', 'leng', 'huai', 'ju', 'chi',
  0x20 => 'wan', 'quan', 'ti', 'bo', 'zu', 'qie', 'yi', 'cu', 'zong', 'cai', 'zong', 'peng', 'zhi', 'zheng', 'dian', 'zhi',
  0x30 => 'yu', 'duo', 'dun', 'chuan', 'yong', 'zhong', 'di', 'zha', 'chen', 'chuai', 'jian', 'gua', 'tang', 'ju', 'fu', 'zu',
  0x40 => 'die', 'pian', 'rou', 'nuo', 'ti', 'cha', 'tui', 'jian', 'dao', 'cuo', 'qi', 'ta', 'qiang', 'nian', 'dian', 'ti',
  0x50 => 'ji', 'nie', 'pan', 'liu', 'zan', 'bi', 'chong', 'lu', 'liao', 'cu', 'tang', 'dai', 'su', 'xi', 'kui', 'ji',
  0x60 => 'zhi', 'qiang', 'di', 'pan', 'zong', 'lian', 'beng', 'zao', 'nian', 'bie', 'tui', 'ju', 'deng', 'ceng', 'xian', 'fan',
  0x70 => 'chu', 'zhong', 'dun', 'bo', 'cu', 'cu', 'jue', 'jue', 'lin', 'ta', 'qiao', 'jue', 'pu', 'liao', 'dun', 'cuan',
  0x80 => 'kuang', 'zao', 'da', 'bi', 'bi', 'zhu', 'ju', 'chu', 'qiao', 'dun', 'chou', 'ji', 'wu', 'yue', 'nian', 'lin',
  0x90 => 'lie', 'zhi', 'li', 'zhi', 'chan', 'chu', 'duan', 'wei', 'long', 'lin', 'xian', 'wei', 'zuan', 'lan', 'xie', 'rang',
  0xA0 => 'sa', 'nie', 'ta', 'qu', 'jie', 'cuan', 'cuo', 'xi', 'kui', 'jue', 'lin', 'shen', 'gong', 'dan', 'fen', 'qu',
  0xB0 => 'ti', 'duo', 'duo', 'gong', 'lang', 'ren', 'luo', 'ai', 'ji', 'ju', 'tang', 'kong', 'lao', 'yan', 'mei', 'kang',
  0xC0 => 'qu', 'lou', 'lao', 'duo', 'zhi', 'yan', 'ti', 'dao', 'ying', 'yu', 'che', 'ya', 'gui', 'jun', 'wei', 'yue',
  0xD0 => 'xin', 'dai', 'xuan', 'fan', 'ren', 'shan', 'kuang', 'shu', 'tun', 'chen', 'dai', 'e', 'na', 'qi', 'mao', 'ruan',
  0xE0 => 'ren', 'qian', 'zhuan', 'hong', 'hu', 'qu', 'kuang', 'di', 'ling', 'dai', 'ao', 'zhen', 'fan', 'kuang', 'yang', 'peng',
  0xF0 => 'bei', 'gu', 'gu', 'pao', 'zhu', 'rong', 'e', 'ba', 'zhou', 'zhi', 'yao', 'ke', 'yi', 'zhi', 'shi', 'ping',
);
